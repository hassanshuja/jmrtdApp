#!/bin/sh

cd %{INSTALL_PATH}/Uninstaller
java -jar uninstaller.jar
