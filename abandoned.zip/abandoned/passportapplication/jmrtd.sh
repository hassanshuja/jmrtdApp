#!/bin/sh

cd %{INSTALL_PATH}/lib
java -jar jmrtd_application.jar

