#ifndef True
#define True	1
#define False	0
#endif

/* fatalerr.c */
extern void fatalerr(char *,char *, char *);
/* syserr.c */
extern void syserr(char *,char *, char *);
